#pragma once

NS_ASSUME_NONNULL_BEGIN
void grant_full_disk_access(void (^completion)(NSError* _Nullable));
NS_ASSUME_NONNULL_END
